export const checkIncludes = (text = "", textToCompare = "") => {

  return text.toLowerCase().includes(textToCompare.toLowerCase());

};
