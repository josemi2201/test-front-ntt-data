import React from "react";
import { createBrowserRouter, Navigate } from "react-router-dom";
import { ProductDetail } from "./ProductDetail";
import { ProductsList } from "./ProductsList";

export const router = createBrowserRouter([
  {
    element: <ProductsList />,
    path: "product"
  },
  {
    element: <ProductDetail />,
    path: "product/:id"
  },
  {
    element: <Navigate to="/product" />,
    path: "*"
  }
]);
