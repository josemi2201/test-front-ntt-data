import { testApi } from "../api/testApi";
import { EMPTY } from "../App";
import { getLocalStorage, setLocalStorage } from "../helpers/localStorage";
import { getDiffBetweenDates } from "../helpers/time";

const TIME_TO_UPDATE = 1;
const TIME_OPERATOR = "hours";

const formatProduct = (product) => {

  return {
    ...product,
    description: product.brand || product.model
      ? `${product.brand} ${product.model}`.trim()
      : "No description",
    priceDescription: product.price
      ? `${product.price} €`
      : "No price"
  };

};

export const useData = () => {


  const getProducts = async () => {

    const {
      updateAt,
      products: productsLocal = []
    } = getLocalStorage("vm-products", true);

    const diffHours = getDiffBetweenDates(
      updateAt,
      new Date(),
      TIME_OPERATOR
    );

    const isExpiredDate =
      diffHours >= TIME_TO_UPDATE ||
      !updateAt ||
      productsLocal.length === EMPTY;

    if (isExpiredDate) {

      const {data} = await testApi.get("/product");
      const products = data.map(formatProduct);

      setLocalStorage("vm-products",
        {
          products,
          updateAt: new Date()
        },
        true);

      return products;

    }

    return productsLocal.map(formatProduct);

  };

  const getProduct = async (id) => {

    const {
      productsDetails: productsDetailsLocal = {}
    } = getLocalStorage("vm-productsDetails", true);

    const product = productsDetailsLocal[id];
    const updateAt = product
      ? product.updateAt
      : null;

    const diffHours = getDiffBetweenDates(
      updateAt,
      new Date(),
      TIME_OPERATOR
    );

    const isExpiredDate =
      diffHours >= TIME_TO_UPDATE ||
      !updateAt ||
      !productsDetailsLocal[id];

    if (isExpiredDate) {

      const { data } = await testApi.get(`/product/${id}`);

      productsDetailsLocal[id] = {
        ...formatProduct(data),
        updateAt: new Date()
      };

      setLocalStorage("vm-productsDetails",
        { productsDetails: productsDetailsLocal[id] },
        true
      );

      return productsDetailsLocal[id];

    }

    return product
      ? formatProduct(product)
      : {};

  };

  return {
    getProduct,
    getProducts
  };

};
