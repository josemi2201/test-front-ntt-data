module.exports = {
    "env": {
        "browser": true,
        "es2021": true
    },
    "extends": [
        "eslint:all",
        "plugin:react/recommended"
    ],
    "overrides": [
    ],
    "parserOptions": {
      "ecmaVersion": "latest",
      "sourceType": "module",
    },
    "settings": {
      "react": {
        "version": 'detect'
      },
      'import/resolver': {
        "node": {
          "paths": ['src'],
          "extensions": ['.js', '.jsx']
        }
      }
    },
    "plugins": [
      "react"
    ],
    "rules": {
      "no-debugger": "warn",
      "no-unused-vars": "warn",
      "object-curly-spacing": "off",
      "linebreak-style": "off",
      "quote-props": "off",
      "indent": ["error", 2],
      "arrow-body-style": "off",
      "sort-imports": "off",
      "sort-keys": "warn",
      "no-use-before-define": "off",
      "one-var": "off",
      "max-lines-per-function": ["error", 80],
      "array-element-newline": "off",
      "no-negated-condition": "off",
      "function-paren-newline": "off",
      "no-ternary": "off",
      "function-call-argument-newline": "off",
      "max-statements": ["error", 12],
      "max-lines-per-function": ["error", 100],
      "no-extra-parens": "off",
      "require-atomic-updates": "off"
    }
}
